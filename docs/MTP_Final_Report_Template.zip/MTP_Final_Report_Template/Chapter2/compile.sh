cd ../
./texps Main
